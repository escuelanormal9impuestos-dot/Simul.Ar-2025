
window.Simular = window.Simular || {};
(function(NS){
  const SETTINGS_KEY = 'settings:avances';
  const STORE_KEY = 'logs:avances';

  function el(html){
    const d = document.createElement('div'); d.innerHTML = html.trim(); return d.firstElementChild;
  }

  const backdrop = el(`<div class="modal-backdrop" id="qcBackdrop" aria-hidden="true">
    <div class="modal" role="dialog" aria-modal="true" aria-labelledby="qcTitle">
      <h3 id="qcTitle">Registrar avance 15’</h3>
      <div class="grid">
        <div>
          <label>Últimos 15 minutos</label>
          <textarea id="qcPast" placeholder="¿Qué hiciste?"></textarea>
        </div>
        <div>
          <label>Próximos 15 minutos</label>
          <textarea id="qcNext" placeholder="¿Qué harás ahora?"></textarea>
        </div>
      </div>
      <div class="grid" style="margin-top:8px">
        <div>
          <label>Bloqueos</label>
          <input id="qcBlockers" type="text" placeholder="¿Qué te frena?"/>
        </div>
        <div>
          <label>Prioridad única</label>
          <input id="qcPriority" type="text" placeholder="Solo una prioridad"/>
        </div>
      </div>
      <div class="actions">
        <button id="qcCancel" class="btn">Cancelar</button>
        <button id="qcSave" class="btn btn-primary">Guardar avance</button>
      </div>
    </div>
  </div>`);

  document.addEventListener('DOMContentLoaded', ()=>{
    document.body.appendChild(backdrop);
    const btn = document.getElementById('quick-advance-btn');
    if(btn) btn.addEventListener('click', openModal);
    document.getElementById('qcCancel').addEventListener('click', closeModal);
    document.getElementById('qcSave').addEventListener('click', saveEntry);
    bootReminder();
  });

  async function getSettings(){
    const def = { enabled: true, intervalMin: 10, lastPromptAt: 0 };
    try { return await NS.store.ensure(SETTINGS_KEY, def); } catch { return def; }
  }
  async function setSettings(v){ try{ await NS.store.set(SETTINGS_KEY, v); }catch(e){ console.error(e) } }

  function openModal(){
    backdrop.classList.add('show-modal'); backdrop.setAttribute('aria-hidden','false');
    document.getElementById('qcPast').focus();
  }
  function closeModal(){
    backdrop.classList.remove('show-modal'); backdrop.setAttribute('aria-hidden','true');
  }

  async function saveEntry(){
    const entry = {
      ts: Date.now(),
      past: document.getElementById('qcPast').value.trim(),
      next: document.getElementById('qcNext').value.trim(),
      blockers: document.getElementById('qcBlockers').value.trim(),
      priority: document.getElementById('qcPriority').value.trim(),
      windowMin: (await getSettings()).intervalMin
    };
    const cur = await NS.store.ensure(STORE_KEY, []);
    cur.push(entry);
    await NS.store.set(STORE_KEY, cur);
    NS.bus.emit('progress.logged', entry);
    closeModal();
  }

  function notify(){
    if(!('Notification' in window)) return;
    if(Notification.permission === 'default'){
      Notification.requestPermission();
    }
    if(Notification.permission === 'granted'){
      const n = new Notification('Registrar avance 15’', { body: '¿Qué hiciste? ¿Qué harás? Bloqueos y 1 prioridad.', silent: true });
      setTimeout(()=>n.close(), 8000);
    }
  }

  async function bootReminder(){
    const st = await getSettings();
    if(!st.enabled) return;
    const iv = Math.max(1, Number(st.intervalMin||10)) * 60 * 1000;
    setInterval(()=>{
      getSettings().then(s=>{
        if(!s.enabled) return;
        notify();
        openModal();
        s.lastPromptAt = Date.now();
        setSettings(s);
      });
    }, iv);
  }

  // Atajo Ctrl/Cmd + J
  document.addEventListener('keydown', (e)=>{
    const ctrl = e.ctrlKey || e.metaKey;
    if(ctrl && (String(e.key).toLowerCase() === 'j')){
      e.preventDefault();
      openModal();
    }
  });

  NS.QuickCapture = { open: openModal, notify, settingsKey: SETTINGS_KEY, storeKey: STORE_KEY };
})(window.Simular);
