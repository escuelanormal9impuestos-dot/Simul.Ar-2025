
window.Simular = window.Simular || {};
(function(NS){
  const routes = {}; 
  NS.router = {
    add(path, meta){ routes[path] = meta },
    go(path){ location.hash = path },
    start(){
      function render(){
        const path = location.hash || '#/home';
        const meta = routes[path] || routes['#/404'];
        if(!meta){ return }
        const container = document.getElementById('view');
        container.innerHTML = '';
        const wrap = document.createElement('div');
        wrap.className = 'view-wrap';
        container.appendChild(wrap);
        let api = {unmount:()=>{}};
        try{
          const out = meta.mount(wrap);
          if(out && typeof out.unmount === 'function') api = out;
        }catch(e){ console.error(e) }
        document.querySelectorAll('.item').forEach(a=>a.classList.toggle('active', a.getAttribute('href')===path));
      }
      window.addEventListener('hashchange', render);
      render();
    }
  };
})(window.Simular);
