
window.Simular = window.Simular || {};
(function(NS){
  const I = {
    dashboard:`<svg viewBox="0 0 24 24"><path d="M3 13h8V3H3v10zM13 21h8V11h-8v10zM3 21h8v-6H3v6zM13 3v6h8V3h-8z"/></svg>`,
    ventas:`<svg viewBox="0 0 24 24"><path d="M6 6l1.5 9a2 2 0 0 0 2 1.7h7.5a2 2 0 0 0 2-1.7L21 8H6"/><circle cx="9" cy="20" r="1.5"/><circle cx="18" cy="20" r="1.5"/></svg>`,
    compras:`<svg viewBox="0 0 24 24"><path d="M3 6h18M6 6l1.5 11a2 2 0 0 0 2 1.7h5a2 2 0 0 0 2-1.7L18 6M8 6V4a3 3 0 0 1 6 0v2"/></svg>`,
    stock:`<svg viewBox="0 0 24 24"><path d="M3 7l9-4 9 4-9 4-9-4zM3 7v10l9 4 9-4V7"/></svg>`,
    tesoreria:`<svg viewBox="0 0 24 24"><path d="M3 7h18v10H3z"/><path d="M7 12h5M6 7V5a2 2 0 0 1 2-2h8l2 2v2"/></svg>`,
    reportes:`<svg viewBox="0 0 24 24"><path d="M4 19V9M10 19V5M16 19v-7M22 21H2"/></svg>`,
    contabilidad:`<svg viewBox="0 0 24 24"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M7 7h10M7 12h10M7 17h6"/></svg>`,
    rrhh:`<svg viewBox="0 0 24 24"><path d="M16 11a4 4 0 1 0-8 0 4 4 0 0 0 8 0z"/><path d="M3 21a7 7 0 0 1 18 0"/></svg>`,
    tributar:`<svg viewBox="0 0 24 24"><path d="M4 4h16v6H4zM6 10v10h12V10"/></svg>`,
    plan:`<svg viewBox="0 0 24 24"><path d="M4 4h12v4H4zM4 8v12h16"/><path d="M10 12h6M10 16h8"/></svg>`,
    contratos:`<svg viewBox="0 0 24 24"><path d="M6 2h9l5 5v15H6z"/><path d="M14 2v5h5M8 12h8M8 16h8"/></svg>`,
    glosario:`<svg viewBox="0 0 24 24"><path d="M4 19V5a2 2 0 0 1 2-2h12v18H6a2 2 0 0 1-2-2z"/><path d="M6 5h12M6 9h12M6 13h8"/></svg>`,
    config:`<svg viewBox="0 0 24 24"><path d="M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6z"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09a1.65 1.65 0 0 0-1-1.51 1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09a1.65 1.65 0 0 0 1.51-1 1.65 1.65 0 0 0-.33-1.82l-.06-.06A2 2 0 1 1 7.04 3.2l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06A2 2 0 1 1 20.8 7.04l-.06.06a1.65 1.65 0 0 0-.33 1.82V9c0 .66.38 1.26 1 1.51.17.07.36.11.55.11H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>`
  };
  NS.Icons = { get: (n)=> I[n] || I.dashboard };
})(window.Simular);
