
window.Simular = window.Simular || {};
(function(NS){
  const DB_NAME = 'simular'; const STORE = 'kv';
  let dbp = null;
  function openDB(){
    if(dbp) return dbp;
    dbp = new Promise((res,rej)=>{
      const req = indexedDB.open(DB_NAME,1);
      req.onupgradeneeded = (e)=>{
        const db = e.target.result;
        if(!db.objectStoreNames.contains(STORE)) db.createObjectStore(STORE);
      };
      req.onsuccess = ()=>res(req.result);
      req.onerror = ()=>rej(req.error);
    });
    return dbp;
  }
  async function set(key, value){
    const db = await openDB();
    return new Promise((res,rej)=>{
      const tx = db.transaction(STORE,'readwrite');
      tx.objectStore(STORE).put(value,key);
      tx.oncomplete=()=>res(true); tx.onerror=()=>rej(tx.error);
    });
  }
  async function get(key){
    const db = await openDB();
    return new Promise((res,rej)=>{
      const tx = db.transaction(STORE,'readonly');
      const r = tx.objectStore(STORE).get(key);
      r.onsuccess=()=>res(r.result??null);
      r.onerror=()=>rej(r.error);
    });
  }
  NS.store = {
    async get(ns){ return (await get(`company:default:${ns}`)) },
    async set(ns, v){ return set(`company:default:${ns}`, v) },
    async ensure(ns, fallback){
      const cur = await this.get(ns);
      if(cur==null){ await this.set(ns, fallback); return fallback }
      return cur;
    }
  };
})(window.Simular);
