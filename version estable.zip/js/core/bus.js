
window.Simular = window.Simular || {};
(function(NS){
  const events = {};
  NS.bus = {
    on(type, handler){
      (events[type] = (events[type] || [])).push(handler);
      return () => { events[type] = (events[type]||[]).filter(h=>h!==handler) }
    },
    emit(type, payload){
      (events[type]||[]).forEach(h=>{ try{ h(payload) }catch(e){ console.error('[bus]', type, e) }});
      console.debug('%c[bus]', 'color:#4aa8ff', type, payload);
    }
  };
})(window.Simular);
