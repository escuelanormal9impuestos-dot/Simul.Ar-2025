
window.Simular = window.Simular || {};
(function(NS){
  const modules = {};
  NS.registerModule = (m)=>modules[m.id]=m;

  function header(el, cls, label){
    const h=document.createElement('div'); h.className='group '+cls;
    h.innerHTML='<span class="bar"></span><span class="label">'+label+'</span>';
    el.appendChild(h);
  }
  function item(el, href, label, cls, icon){
    const a=document.createElement('a'); a.href=href; a.className='item '+(cls||'');
    a.innerHTML='<span class="ico">'+NS.Icons.get(icon)+'</span><span>'+label+'</span>';
    el.appendChild(a);
  }

  function buildMenu(){
    const el = document.getElementById('menu');
    el.innerHTML='';
    header(el,'','Dashboard');
    item(el,'#/home','Dashboard','erp','dashboard');
    header(el,'erp','ERP');
    item(el,'#/ventas','Ventas','erp','ventas');
    item(el,'#/compras','Compras','erp','compras');
    item(el,'#/stock','Stock','erp','stock');
    item(el,'#/tesoreria','Tesorería','erp','tesoreria');
    item(el,'#/reportes','Reportes','erp','reportes');
    header(el,'internal','Herramientas internas');
    item(el,'#/contabilidad','Contabilidad','internal','contabilidad');
    item(el,'#/rrhh','RR.HH. · Liquidación','internal','rrhh');
    item(el,'#/avances','Avances 15’','internal','reportes');
    header(el,'external','Herramienta externa');
    item(el,'#/tributar','Tribut.Ar (sim)','external','tributar');
    header(el,'repo','Repositorio');
    item(el,'#/plan','Plan de Negocios','repo','plan');
    item(el,'#/contratos','Contratos sociales','repo','contratos');
    item(el,'#/glosario','Glosario','repo','glosario');
  }

  function registerRoutes(){
    for(const m of Object.values(modules)){
      if(m.init) try{ m.init(NS.bus, NS.store) }catch(e){ console.error(e) }
      (m.routes||[]).forEach(r=>{
        NS.router.add(r.path, { title:r.title||m.name, mount:(container)=>{
          const wrap=document.createElement('div'); wrap.id='mod-'+m.id; wrap.className='mod-'+m.id;
          container.appendChild(wrap);
          let api={unmount:()=>{}};
          if(m.mount){ const out = m.mount(wrap, r.params||{}); if(out && typeof out.unmount==='function') api=out; }
          return api;
        }});
      });
    }
    NS.router.add('#/404',{title:'404', mount:(el)=>{ el.innerHTML='<div class="card"><h2>404</h2><p>Ruta no encontrada.</p></div>'; return {unmount(){}}}});
  }

  NS.boot = function(){
    buildMenu();
    registerRoutes();
    NS.router.start();
  };
})(window.Simular);
