
window.Simular = window.Simular || {};
(function(NS){
  async function globalEnabled(){
    try{ return await NS.store.ensure('help:global:enabled', true); }catch{ return true }
  }
  NS.help = {
    async inject(container, moduleId, html){
      const g = await globalEnabled();
      const visible = await NS.store.ensure(`help:module:${moduleId}:visible`, true);
      if(!g || !visible) return;
      const wrapper = document.createElement('div');
      wrapper.className = 'card help-card';
      wrapper.innerHTML = `
        <div class="help-head">
          <strong>Ayuda rápida</strong>
          <div style="display:flex;gap:8px;align-items:center">
            <button class="btn btn-ghost" id="hide">Ocultar</button>
          </div>
        </div>
        <div class="help-body">${html}</div>
      `;
      const first = container.firstElementChild;
      if(first) container.insertBefore(wrapper, first); else container.appendChild(wrapper);
      wrapper.querySelector('#hide').onclick = async ()=>{
        try{ await NS.store.set(`help:module:${moduleId}:visible`, false); }catch(e){ console.error(e) }
        wrapper.remove();
      };
    }
  };

  // Wire topbar toggle "Ayuda"
  document.addEventListener('DOMContentLoaded', ()=>{
    const btn = document.getElementById('btnHelp');
    if(btn){
      btn.addEventListener('click', async ()=>{
        const cur = await NS.store.ensure('help:global:enabled', true);
        await NS.store.set('help:global:enabled', !cur);
        // Fuerza re-render del módulo actual
        window.dispatchEvent(new HashChangeEvent('hashchange'));
      });
    }
  });
})(window.Simular);
