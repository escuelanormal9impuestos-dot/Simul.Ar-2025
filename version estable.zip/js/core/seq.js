
window.Simular = window.Simular || {};
(function(NS){
  NS.seq = {
    async next(type, pv='0001'){
      try{
        const data = await NS.store.ensure('seq', {});
        data[type] = data[type] || {};
        const cur = Number((data[type][pv]||0)) + 1;
        data[type][pv] = cur;
        await NS.store.set('seq', data);
        return String(cur).padStart(8,'0');
      }catch(e){
        console.error('seq.next error', e);
        return String(Math.floor(Math.random()*1e8)).padStart(8,'0');
      }
    }
  };
})(window.Simular);
