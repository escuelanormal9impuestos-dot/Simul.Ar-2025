
Simular.registerModule({ id:'compras', name:'Compras', routes:[{ path:'#/compras', title:'Compras' }],
  mount(el){
    el.innerHTML = `<div class="card"><h2>Compras — Factura de compra</h2>
      <div style="display:flex;gap:10px;flex-wrap:wrap;margin:10px 0">
        <input id="prov" placeholder="Proveedor" />
        <input id="sku" placeholder="SKU" value="SKU-001" />
        <input id="nom" placeholder="Nombre" style="width:220px" />
        <input id="q" type="number" placeholder="Cant." value="1" style="width:110px" />
        <input id="p" type="number" step="0.01" placeholder="Precio" style="width:140px" />
        <select id="iva">
          <option value="21">IVA 21%</option>
          <option value="10.5">IVA 10,5%</option>
          <option value="0">Exento</option>
        </select>
        <button id="agregar" class="btn">Agregar ítem</button>
      </div>
      <div class="card" id="items"></div>
      <div style="display:flex;gap:10px;flex-wrap:wrap;margin:10px 0">
        <button id="compra" class="btn btn-primary">Registrar compra</button>
      </div>
      <pre id="prev" class="note"></pre>
    </div>`;
    Simular.help.inject(el, 'compras', `
<ul>
  <li>Cargá <strong>Proveedor</strong> e ítems con alícuota de IVA por renglón.</li>
  <li>Al <strong>Registrar compra</strong> impacta IVA Compras y puede incrementar Stock.</li>
  <li>Usá esto para simular costo y crédito fiscal.</li>
</ul>
`);

    const $=s=>el.querySelector(s);
    const fmt = n => '$ ' + (Number(n||0).toFixed(2));
    const items=[];
    function render(){
      const bruto = items.reduce((a,it)=>a+it.q*it.p,0);
      const vat = {};
      for(const it of items){
        const key=String(it.ivaRate);
        vat[key]=vat[key]||{net:0,iva:0};
        vat[key].net += it.q*it.p;
        vat[key].iva += (it.q*it.p)*(it.ivaRate/100);
      }
      const ivaTotal = Object.values(vat).reduce((a,b)=>a+b.iva,0);
      const total = bruto + ivaTotal;
      $('#items').innerHTML = items.length? items.map(it=>`<div class="row"><span>${it.sku} · ${it.nom} × ${it.q}</span><span>${fmt(it.p)} · IVA ${it.ivaRate}%</span></div>`).join('') : '<p class="note">Agregá items</p>';
      $('#prev').textContent = JSON.stringify({items, totals:{bruto, iva:ivaTotal, gross:total}, vatBreakdown:vat}, null, 2);
      return { bruto, ivaTotal, total, vatBreakdown:vat };
    }
    $('#agregar').onclick=()=>{
      items.push({ sku:$('#sku').value||'SKU-001', nom:$('#nom').value||'Item', q:+($('#q').value||1), p:+($('#p').value||0), ivaRate:+($('#iva').value||21) });
      render();
    };
    $('#compra').onclick=()=>{
      const t = render();
      const payload = { id:'PC-'+Date.now(), supplier:$('#prov').value||'Prov', items: items.map(it=>({sku:it.sku,q:it.q})), totals:{bruto:t.bruto, iva:t.ivaTotal, gross:t.total}, vatBreakdown:t.vatBreakdown, date:new Date().toISOString() };
      Simular.bus.emit('purchase.created', payload);
      alert('Compra registrada ✅');
    };
    render(); 
    return {unmount(){}};
  }
});
