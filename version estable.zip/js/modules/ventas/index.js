
Simular.registerModule({
  id: 'ventas',
  name: 'Ventas',
  routes: [{ path: '#/ventas', title: 'Ventas' }],
  init(bus, store){},
  async mount(el){
    // Helpers
    const $ = (sel,ctx=el)=>ctx.querySelector(sel);
    const today = ()=> new Date().toISOString().slice(0,10);
    const money = n => '$ ' + Number(n||0).toLocaleString('es-AR',{minimumFractionDigits:2, maximumFractionDigits:2});

    function renderInvoicePreview(target, {
      doc='COTIZACIÓN', tipo='B', pv='0001', nro='00000000', fecha,
      cliente='Consumidor Final', cuit='CF', email='',
      items=[], descuentoPct=0, totals={bruto:0, descuento:0, neto:0, ivaTotal:0, perIva:0, perIibb:0, total:0},
      cae=null, caeVto=null
    }){
      const rows = (items||[]).map(it=>{
        const q = Number(it.q||0), pu = Number(it.price||0);
        const iva = Number(it.ivaRate||0);
        return `<tr>
          <td>${it.sku||''} — ${it.nombre||''}</td>
          <td>${q}</td>
          <td>${money(pu)}</td>
          <td>${iva}%</td>
          <td>${money(q*pu)}</td>
        </tr>`;
      }).join('') || `<tr><td colspan="5" style="text-align:center;color:#888">Sin ítems</td></tr>`;

      target.innerHTML = `
        <div class="invoice-card">
          <div class="invoice-head">
            <div>
              <div class="invoice-badge">${doc}</div>
              <div class="invoice-meta">Tipo ${tipo} · PV ${pv} · Nº ${nro}</div>
              <div class="invoice-meta">Fecha: ${fecha||today()}</div>
            </div>
            <div>
              <div><strong>${cliente}</strong></div>
              <div class="invoice-meta">CUIT: ${cuit}</div>
              <div class="invoice-meta">${email||''}</div>
            </div>
          </div>
          <table class="invoice-table">
            <thead><tr><th>Ítem</th><th>Cant.</th><th>Precio</th><th>IVA</th><th>Subtotal</th></tr></thead>
            <tbody>${rows}</tbody>
          </table>
          <div class="invoice-totals">
            <div class="row"><span>Bruto</span><strong>${money(totals.bruto||0)}</strong></div>
            <div class="row"><span>Descuento (${descuentoPct||0}%)</span><strong>- ${money(totals.descuento||0)}</strong></div>
            <div class="row"><span>Neto</span><strong>${money(totals.neto||0)}</strong></div>
            <div class="row"><span>IVA</span><strong>${money(totals.ivaTotal||totals.iva||0)}</strong></div>
            <div class="row"><span>Percep. IVA</span><strong>${money(totals.perIva||0)}</strong></div>
            <div class="row"><span>Percep. IIBB</span><strong>${money(totals.perIibb||0)}</strong></div>
            <div class="row" style="font-size:1.1rem"><span>Total</span><strong>${money(totals.total||0)}</strong></div>
          </div>
          ${cae ? `<div class="invoice-legal">CAE: ${cae} — Vto: ${caeVto}</div>` : ''}
        </div>`;
    }

    function calcTotals(items, descuentoPct=0, perIvaPct=0, perIibbPct=0){
      const bruto = (items||[]).reduce((a,it)=> a + Number(it.q||0)*Number(it.price||0), 0);
      const descuento = bruto * (Number(descuentoPct||0)/100);
      const neto = bruto - descuento;
      const ivaTotal = (items||[]).reduce((a,it)=> a + (Number(it.q||0)*Number(it.price||0) - (Number(it.q||0)*Number(it.price||0)*(Number(descuentoPct||0)/100))) * (Number(it.ivaRate||0)/100), 0);
      const perIva = neto * (Number(perIvaPct||0)/100);
      const perIibb = neto * (Number(perIibbPct||0)/100);
      const total = neto + ivaTotal + perIva + perIibb;
      return {bruto, descuento, neto, ivaTotal, perIva, perIibb, total};
    }

    // Layout básico
    el.innerHTML = `
      <div class="card">
        <div class="row" style="justify-content:space-between;align-items:center">
          <strong>Ventas — Flujo</strong>
          <div class="row" style="gap:6px">
            <button id="tabCot" data-tab="COT" class="btn btn-primary">Cotización</button>
            <button id="tabOV" data-tab="OV" class="btn">Orden de Venta</button>
            <button id="tabFC" data-tab="FC" class="btn">Factura</button>
            <button id="tabREM" data-tab="REM" class="btn">Remito</button>
            <button id="tabNC" data-tab="NC" class="btn">Nota de Crédito</button>
            <button id="resetForm" class="btn btn-ghost">Nuevo</button>
          </div>
        </div>
      </div>
      <div id="content"></div>
    `;

    // Ayuda
    Simular.help.inject(el, 'ventas', `
<ul>
  <li><strong>Cotización</strong>: cargá cliente (o tocá <em>CF</em>), agregá ítems y mirá la previsualización.</li>
  <li><strong>OV</strong>: Confirmar. Si total alto o descuento >15% requiere <em>Aprobar</em>.</li>
  <li><strong>Remito</strong>: entregá parcial/total y baja stock.</li>
  <li><strong>Factura</strong>: ajustá Percep. IVA/IIBB y Emití. Podés imprimir y registrar <em>Recibo</em>.</li>
</ul>`);

    const content = $('#content');

    // Vistas
    function viewCotizacion(){
      const wrap = document.createElement('div');
      wrap.className = 'grid cols-2';
      wrap.innerHTML = `
        <div class="card">
          <strong>Cotización</strong>
          <div style="display:flex;gap:8px;flex-wrap:wrap;margin:8px 0">
            <input id="cli" placeholder="Razón social" />
            <input id="cuit" placeholder="CUIT" />
            <input id="email" placeholder="Email" />
            <select id="condIva">
              <option value="CF">Consumidor Final</option>
              <option value="RI">Resp. Inscripto</option>
              <option value="MONO">Monotributo</option>
              <option value="EX">Exento</option>
            </select>
            <button id="btnCF" class="btn">CF</button>
          </div>
          <div style="display:flex;gap:8px;flex-wrap:wrap;margin:8px 0">
            <input id="sku" placeholder="SKU" style="width:120px"/>
            <input id="nom" placeholder="Nombre" style="flex:1"/>
            <input id="q" type="number" placeholder="Cant." style="width:120px"/>
            <input id="price" type="number" placeholder="Precio" style="width:140px"/>
            <select id="iva"><option>21</option><option>10.5</option><option>0</option></select>
            <button id="add" class="btn">Agregar</button>
          </div>
          <div id="items"></div>
          <div class="row" style="gap:8px;margin-top:8px">
            <label>Desc. %</label><input id="desc" type="number" value="0" style="width:120px"/>
            <label>Válido hasta</label><input id="valido" type="date" value="${today()}"/>
            <button id="toOV" class="btn btn-primary">Convertir a OV</button>
          </div>
        </div>
        <div class="card">
          <strong>Vista previa</strong>
          <div id="preview" class="invoice-card"></div>
        </div>
      `;

      const items = [];
      function render(){
        const tot = calcTotals(items, Number($('#desc',wrap).value||0), 0, 0);
        renderInvoicePreview($('#preview',wrap), {
          doc:'COTIZACIÓN', tipo:'—', pv:'—', nro:'—', fecha: $('#valido',wrap).value || today(),
          cliente: $('#cli',wrap).value || 'Consumidor Final', cuit: $('#cuit',wrap).value || 'CF', email: $('#email',wrap).value || '',
          items, descuentoPct: Number($('#desc',wrap).value||0), totals: tot
        });
        $('#items',wrap).innerHTML = items.map((it,i)=>`
          <div class="row"><span>${it.sku} — ${it.nombre}</span><span>${it.q} x ${money(it.price)} (IVA ${it.ivaRate}%)</span><button data-i="${i}" class="btn btn-ghost">Quitar</button></div>
        `).join('');
      }

      $('#add',wrap).onclick = ()=>{
        items.push({
          sku: $('#sku',wrap).value || 'SKU',
          nombre: $('#nom',wrap).value || 'Producto',
          q: Number($('#q',wrap).value||1),
          price: Number($('#price',wrap).value||0),
          ivaRate: Number($('#iva',wrap).value||21)
        });
        ['sku','nom','q','price'].forEach(id=> $('#'+id,wrap).value='');
        render();
      };
      wrap.addEventListener('click', (e)=>{
        const btn = e.target.closest('button[data-i]'); if(!btn) return;
        const i = Number(btn.getAttribute('data-i')); items.splice(i,1); render();
      });

      $('#btnCF',wrap).onclick = ()=>{ $('#condIva',wrap).value='CF'; $('#cuit',wrap).value='CF'; if(!$('#cli',wrap).value) $('#cli',wrap).value='Consumidor Final'; render(); };
      $('#condIva',wrap).onchange = ()=>{ if($('#condIva',wrap).value==='CF'){ $('#cuit',wrap).value='CF'; if(!$('#cli',wrap).value) $('#cli',wrap).value='Consumidor Final'; } render(); };
      ['desc','valido'].forEach(id=> $('#'+id,wrap).oninput = render);

      $('#toOV',wrap).onclick = async ()=>{
        const ov = {
          id: 'OV-'+Date.now(),
          header: { cliente: $('#cli',wrap).value||'CF', cuit: $('#cuit',wrap).value||'CF', email: $('#email',wrap).value||'', condIva: $('#condIva',wrap).value||'CF' },
          items: items.slice(),
          descuentoPct: Number($('#desc',wrap).value||0),
          date: today(),
          pv: '0001',
          totals: calcTotals(items, Number($('#desc',wrap).value||0), 0, 0),
          status: 'borrador', approved: false, requiresApproval: false
        };
        const list = await Simular.store.ensure('salesOrders', []);
        list.push(ov); await Simular.store.set('salesOrders', list);
        alert('OV creada ✅  '+ov.id);
        selectTab('OV');
      };

      render();
      return wrap;
    }

    function viewOrden(){
      const wrap = document.createElement('div');
      wrap.className = 'grid cols-2';
      wrap.innerHTML = `
        <div class="card">
          <strong>Orden de Venta</strong>
          <div style="display:flex;gap:8px;flex-wrap:wrap;margin:8px 0">
            <select id="pickOV"></select>
            <button id="confirm" class="btn btn-primary">Confirmar</button>
            <button id="approve" class="btn">Aprobar</button>
            <button id="toFC" class="btn">Convertir a Factura</button>
          </div>
          <div id="ovView" class="note"></div>
        </div>
        <div class="card">
          <strong>Listados</strong>
          <div><em>OV</em></div>
          <div id="listOV" style="margin-top:8px"></div>
          <div class="sep"></div>
          <div><em>Facturas</em></div>
          <div id="listFC" style="margin-top:8px"></div>
        </div>
      `;

      async function refreshLists(){
        const list = await Simular.store.ensure('salesOrders', []);
        $('#listOV',wrap).innerHTML = list.slice().reverse().slice(0,5).map(o=> `<div class="row"><span>${o.id}</span><span>${o.status||''}${o.requiresApproval?' (req.aprob.)':''}</span></div>`).join('') || '<div>Sin OV</div>';
        const invs = await Simular.store.ensure('invoices', []);
        $('#listFC',wrap).innerHTML = invs.slice().reverse().slice(0,5).map(i=> `<div class="row"><span>${i.id}</span><span>${money(i.totals?.gross||i.totals?.total||0)}</span></div>`).join('') || '<div>Sin facturas</div>';
      }

      async function loadOVs(){
        const list = await Simular.store.ensure('salesOrders', []);
        const sel = $('#pickOV',wrap);
        sel.innerHTML = list.map(o=> `<option value="${o.id}">${o.id} — ${o.header?.cliente||'CF'}</option>`).join('') || '<option>(sin OV)</option>';
      }

      async function show(){
        const id = $('#pickOV',wrap).value;
        const list = await Simular.store.ensure('salesOrders', []);
        const ov = list.find(x=>x.id===id);
        if(!ov){ $('#ovView',wrap).innerHTML = '—'; return; }
        $('#ovView',wrap).innerHTML = `${ov.header?.cliente||'CF'} · ${ov.items?.length||0} ítems · Total: ${money(ov.totals?.total||0)} ${ov.requiresApproval?' · Requiere aprobación':''} ${ov.approved?' · Aprobada':''}`;
      }

      $('#confirm',wrap).onclick = async ()=>{
        const list = await Simular.store.ensure('salesOrders', []);
        const id = $('#pickOV',wrap).value; const ov = list.find(x=>x.id===id);
        if(!ov){ alert('Elegí una OV'); return; }
        ov.status='confirmada';
        const tot = ov.totals?.total||0, desc = Number(ov.descuentoPct||0);
        if(tot>200000 || desc>15){ ov.requiresApproval=true; ov.approved=false; }
        const res = await Simular.store.ensure('reservations', []);
        res.push({ ovId: ov.id, items: (ov.items||[]).map(it=>({sku:it.sku, q:it.q})) });
        await Simular.store.set('reservations', res);
        await Simular.store.set('salesOrders', list);
        alert('OV confirmada ✅'); await loadOVs(); await show(); await refreshLists();
      };
      $('#approve',wrap).onclick = async ()=>{
        const list = await Simular.store.ensure('salesOrders', []);
        const id = $('#pickOV',wrap).value; const ov = list.find(x=>x.id===id);
        if(!ov){ alert('Elegí una OV'); return; }
        ov.approved=true; ov.requiresApproval=false; await Simular.store.set('salesOrders', list);
        alert('OV aprobada ✅'); await show(); await refreshLists();
      };
      $('#toFC',wrap).onclick = async ()=>{
        const list = await Simular.store.ensure('salesOrders', []);
        const id = $('#pickOV',wrap).value; const ov = list.find(x=>x.id===id);
        if(!ov){ alert('Elegí una OV'); return; }
        if(ov.requiresApproval && !ov.approved){ alert('OV requiere aprobación'); return; }
        await Simular.store.set('current:toInvoice', ov);
        await Simular.store.set('current:ovId', ov.id);
        selectTab('FC');
      };

      $('#pickOV',wrap).onchange = show;

      loadOVs().then(show).then(refreshLists);
      return wrap;
    }

    function viewRemito(){
      const wrap = document.createElement('div');
      wrap.className = 'grid cols-2';
      wrap.innerHTML = `
        <div class="card">
          <strong>Remito</strong>
          <div style="display:flex;gap:8px;flex-wrap:wrap;margin:8px 0">
            <select id="pickOVforREM"></select>
            <button id="genREM" class="btn btn-primary">Generar remito</button>
            <button id="printREM" class="btn">Descargar PDF</button>
          </div>
          <div id="remForm" class="note"></div>
        </div>
        <div class="card">
          <strong>Vista previa</strong>
          <div id="previewREM" class="invoice-card"></div>
        </div>
      `;

      async function loadOVs(){
        const list = await Simular.store.ensure('salesOrders', []);
        $('#pickOVforREM',wrap).innerHTML = list.map(o=> `<option value="${o.id}">${o.id} — ${o.header?.cliente||'CF'}</option>`).join('') || '<option>(sin OV)</option>';
      }

      async function renderForm(){
        const id = $('#pickOVforREM',wrap).value;
        const list = await Simular.store.ensure('salesOrders', []);
        const ov = list.find(x=>x.id===id);
        const deliveries = await Simular.store.ensure('deliveries', []);
        const delivered = {};
        deliveries.filter(d=>d.ovId===id).forEach(d=> (d.items||[]).forEach(it=> delivered[it.sku]=(delivered[it.sku]||0)+Number(it.q||0) ));

        const rows = (ov?.items||[]).map(it=>{
          const pend = Math.max(0, Number(it.q||0) - Number(delivered[it.sku]||0));
          return `<div class="row">
            <span style="min-width:140px">${it.sku}</span>
            <span>${it.nombre||''}</span>
            <span>Pend.: <strong>${pend}</strong></span>
            <input type="number" min="0" max="${pend}" value="${pend}" data-sku="${it.sku}" style="width:100px" />
          </div>`;
        }).join('') || '<div class="note">No hay ítems o todo entregado.</div>';
        $('#remForm',wrap).innerHTML = rows;

        const items = Array.from(wrap.querySelectorAll('#remForm input[type="number"]')).map(inp=>{
          const sku = inp.getAttribute('data-sku'); const q = Number(inp.value||0);
          const it = (ov?.items||[]).find(x=>x.sku===sku) || {sku, nombre:sku, price:0, ivaRate:0};
          return {...it, q};
        }).filter(x=>x.q>0);
        renderInvoicePreview($('#previewREM',wrap), {
          doc:'REMITO', tipo:'—', pv: ov?.pv||'—', nro:'(auto)', fecha: today(),
          cliente: ov?.header?.cliente || 'CF', cuit: ov?.header?.cuit || 'CF', items, descuentoPct:0, totals:{bruto:0,descuento:0,neto:0,ivaTotal:0,total:0}
        });
      }

      wrap.addEventListener('input', (e)=>{ if(e.target.matches('#remForm input[type="number"]')) renderForm(); });

      $('#genREM',wrap).onclick = async ()=>{
        const id = $('#pickOVforREM',wrap).value;
        const list = await Simular.store.ensure('salesOrders', []);
        const ov = list.find(x=>x.id===id);
        if(!ov){ alert('Elegí una OV'); return; }
        const inputs = Array.from(wrap.querySelectorAll('#remForm input[type="number"]'));
        const items = inputs.map(inp=>{
          const sku = inp.getAttribute('data-sku'); const q = Number(inp.value||0);
          const it = (ov.items||[]).find(x=>x.sku===sku) || {sku, nombre:sku, price:0, ivaRate:0};
          return {sku, nombre: it.nombre||sku, q, price: it.price||0, ivaRate: it.ivaRate||0};
        }).filter(x=>x.q>0);
        if(!items.length){ alert('Nada para remitir'); return; }
        const seqNo = await Simular.seq.next('REM', ov?.pv||'0001');
        const rem = { id: 'REM-'+Date.now(), ovId: id, pv: (ov?.pv||'0001'), number: seqNo, date: new Date().toISOString(), items };
        const deliv = await Simular.store.ensure('deliveries', []); deliv.push(rem); await Simular.store.set('deliveries', deliv);

        const inv = await Simular.store.ensure('inventory', {'SKU-001':10,'SKU-002':5,'SKU-003':20});
        items.forEach(it=>{ inv[it.sku] = (inv[it.sku]||0) - Number(it.q||0); });
        await Simular.store.set('inventory', inv);

        const res = await Simular.store.ensure('reservations', []);
        const rr = res.find(r=>r.ovId===id);
        if(rr){
          items.forEach(it=>{
            const row = (rr.items||[]).find(x=>x.sku===it.sku);
            if(row) row.q = Math.max(0, Number(row.q||0) - Number(it.q||0));
          });
          rr.items = (rr.items||[]).filter(x=>x.q>0);
        }
        const rebuilt = res.map(r=> r.ovId===id ? rr : r).filter(r=> r && (r.items||[]).length>0);
        await Simular.store.set('reservations', rebuilt);

        Simular.bus.emit('delivery.created', rem);
        renderInvoicePreview($('#previewREM',wrap), { doc:'REMITO', tipo:'—', pv: rem.pv, nro: rem.number, fecha: rem.date, cliente: ov?.header?.cliente || 'CF', cuit: ov?.header?.cuit || 'CF', items, descuentoPct:0, totals:{bruto:0,descuento:0,neto:0,ivaTotal:0,total:0} });
        alert('Remito generado ✅  '+ rem.id + ' · Nº '+ rem.number);
        renderForm();
      };

      $('#printREM',wrap).onclick = ()=>{
        const w = window.open('','_blank');
        const html = '<html><body>'+ $('#previewREM',wrap).outerHTML +'</body></html>';
        w.document.write(html); w.document.close(); w.print(); setTimeout(()=>w.close(), 400);
      };

      loadOVs().then(renderForm);
      return wrap;
    }

    
    function viewNC(){
      const wrap = document.createElement('div');
      wrap.className = 'grid cols-2';
      wrap.innerHTML = `
        <div class="card">
          <strong>Nota de Crédito</strong>
          <div style="display:flex;gap:8px;flex-wrap:wrap;margin:8px 0">
            <select id="pickFCforNC"></select>
            <label style="display:flex;align-items:center;gap:6px"><input id="ncStock" type="checkbox"/> Devolver stock</label>
            <button id="emitNC" class="btn btn-primary">Emitir NC</button>
            <button id="printNC" class="btn">Descargar PDF</button>
          </div>
          <div id="ncForm" class="note"></div>
        </div>
        <div class="card">
          <strong>Vista previa</strong>
          <div id="previewNC" class="invoice-card"></div>
        </div>
      `;

      async function loadInvoices(){
        const invs = await Simular.store.ensure('invoices', []);
        $('#pickFCforNC',wrap).innerHTML = invs.map(i=> `<option value="${i.id}">${i.id} — ${i.customer||'CF'} — ${i.pv||'0001'}-${i.number||''}</option>`).join('') || '<option>(sin facturas)</option>';
      }

      async function renderForm(){
        const id = $('#pickFCforNC',wrap).value;
        const invs = await Simular.store.ensure('invoices', []);
        const fc = invs.find(x=>x.id===id);
        const rows = (fc?.items||[]).map(it=>{
          const max = Number(it.q||0);
          return `<div class="row">
            <span style="min-width:140px">${it.sku}</span>
            <span>${it.nombre||''}</span>
            <span>Máx.: <strong>${max}</strong></span>
            <input type="number" min="0" max="${max}" value="0" data-sku="${it.sku}" style="width:100px" />
          </div>`;
        }).join('') || '<div class="note">No hay ítems en la factura.</div>';
        $('#ncForm',wrap).innerHTML = rows;

        const items = Array.from(wrap.querySelectorAll('#ncForm input[type="number"]')).map(inp=>{
          const sku = inp.getAttribute('data-sku'); const q = Number(inp.value||0);
          const it = (fc?.items||[]).find(x=>x.sku===sku) || {sku, nombre:sku, price:0, ivaRate:0};
          return {...it, q};
        }).filter(x=>x.q>0);

        const tot = calcTotals(items, 0, 0, 0);
        renderInvoicePreview($('#previewNC',wrap), {
          doc:'NOTA DE CRÉDITO', tipo: fc?.type||'B', pv: fc?.pv||'0001', nro:'(auto)', fecha: new Date().toISOString().slice(0,10),
          cliente: fc?.customer||'CF', cuit: fc?.cuit||'CF', items, descuentoPct:0, totals: tot
        });
      }

      wrap.addEventListener('input', (e)=>{ if(e.target.matches('#ncForm input[type="number"]')) renderForm(); });

      $('#emitNC',wrap).onclick = async ()=>{
        const id = $('#pickFCforNC',wrap).value;
        const invs = await Simular.store.ensure('invoices', []);
        const fc = invs.find(x=>x.id===id);
        if(!fc){ alert('Elegí una factura'); return; }
        const inputs = Array.from(wrap.querySelectorAll('#ncForm input[type="number"]'));
        const items = inputs.map(inp=>{
          const sku = inp.getAttribute('data-sku'); const q = Number(inp.value||0);
          const it = (fc.items||[]).find(x=>x.sku===sku) || {sku, nombre:sku, price:0, ivaRate:0};
          return {sku, nombre: it.nombre||sku, q, price: it.price||0, ivaRate: it.ivaRate||0};
        }).filter(x=>x.q>0);
        if(!items.length){ alert('Nada para acreditar'); return; }
        const pv = fc.pv || '0001';
        const number = await Simular.seq.next('NC', pv);
        const tot = calcTotals(items, 0, 0, 0);
        const nc = { id: 'NC-'+Date.now(), type: 'NC', pv, number, date: new Date().toISOString().slice(0,10), customer: fc.customer, cuit: fc.cuit, items, totals: tot, refInvoice: fc.id };
        const notes = await Simular.store.ensure('creditNotes', []); notes.push(nc); await Simular.store.set('creditNotes', notes);

        // AR: documento negativo
        const ar = await Simular.store.ensure('ar:docs', []);
        ar.push({ id: nc.id, date: nc.date, customer: nc.customer, total: -nc.totals.total, balance: -nc.totals.total });
        await Simular.store.set('ar:docs', ar);

        // Stock: devolver si aplica
        if($('#ncStock',wrap).checked){
          const inv = await Simular.store.ensure('inventory', {'SKU-001':10,'SKU-002':5,'SKU-003':20});
          items.forEach(it=>{ inv[it.sku] = (inv[it.sku]||0) + Number(it.q||0); });
          await Simular.store.set('inventory', inv);
        }

        renderInvoicePreview($('#previewNC',wrap), {
          doc:'NOTA DE CRÉDITO', tipo: fc.type||'B', pv, nro: number, fecha: nc.date,
          cliente: nc.customer, cuit: nc.cuit, items, descuentoPct:0, totals: tot
        });
        alert('Nota de Crédito emitida ✅  '+nc.id+' · Nº '+pv+'-'+number);
      };

      $('#printNC',wrap).onclick = ()=>{
        const w = window.open('','_blank'); const html = '<html><body>'+ $('#previewNC',wrap).outerHTML +'</body></html>';
        w.document.write(html); w.document.close(); w.print(); setTimeout(()=>w.close(), 400);
      };

      loadInvoices().then(renderForm);
      return wrap;
    }
function viewFactura(){
      const wrap = document.createElement('div');
      wrap.className = 'grid cols-2';
      wrap.innerHTML = `
        <div class="card">
          <strong>Factura</strong>
          <div style="display:flex;gap:8px;flex-wrap:wrap;margin:8px 0">
            <select id="tipo"><option>A</option><option selected>B</option><option>C</option><option>M</option><option>E</option></select>
            <input id="pv" placeholder="Pto Vta" value="0001" style="width:120px"/>
            <input id="nro" placeholder="Número" value="(auto)" style="width:120px"/>
            <input id="fecha" type="date" value="${today()}" />
          </div>
          <div style="display:flex;gap:8px;flex-wrap:wrap;margin:8px 0">
            <input id="cli" placeholder="Cliente" />
            <input id="cuit" placeholder="CUIT" />
          </div>
          <div id="items" class="note"></div>
          <div class="row" style="gap:8px;margin-top:8px">
            <label>Desc. %</label><input id="desc" type="number" value="0" style="width:80px"/>
            <label>Percep. IVA %</label><input id="perIva" type="number" value="0" style="width:90px"/>
            <label>Percep. IIBB %</label><input id="perIibb" type="number" value="0" style="width:90px"/>
            <button id="emit" class="btn btn-primary">Emitir</button>
            <button id="printDoc" class="btn">Descargar PDF</button>
            <button id="recibo" class="btn">Registrar pago / Recibo</button>
          </div>
        </div>
        <div class="card">
          <strong>Vista previa</strong>
          <div id="preview" class="invoice-card"></div>
        </div>
      `;

      let items = [];
      async function loadFromOV(){
        const from = await Simular.store.get('current:toInvoice');
        if(from){
          items = (from.items||[]).map(x=> ({...x}));
          $('#cli',wrap).value = from.header?.cliente||'CF';
          $('#cuit',wrap).value = from.header?.cuit||'CF';
        }
      }

      function render(){
        const tot = calcTotals(items, Number($('#desc',wrap).value||0), Number($('#perIva',wrap).value||0), Number($('#perIibb',wrap).value||0));
        renderInvoicePreview($('#preview',wrap), {
          doc:'FACTURA', tipo: $('#tipo',wrap).value, pv: $('#pv',wrap).value||'0001', nro: $('#nro',wrap).value||'(auto)',
          fecha: $('#fecha',wrap).value, cliente: $('#cli',wrap).value||'CF', cuit: $('#cuit',wrap).value||'CF', items,
          descuentoPct: Number($('#desc',wrap).value||0), totals: tot
        });
        $('#items',wrap).innerHTML = items.map(it=> `<div class="row"><span>${it.sku} — ${it.nombre}</span><span>${it.q} x ${money(it.price)} (IVA ${it.ivaRate}%)</span></div>`).join('') || '<div class="note">Sin ítems (tomados de la OV si existía).</div>';
      }

      $('#emit',wrap).onclick = async ()=>{
        if(!items.length){ alert('No hay ítems'); return; }
        const autoNumberNeeded = !$('#nro',wrap).value || $('#nro',wrap).value==='(auto)';
        const autogeneratedNumber = autoNumberNeeded ? await Simular.seq.next('FC', $('#pv',wrap).value||'0001') : $('#nro',wrap).value;
        const invoice = {
          id:'FC-'+Date.now(),
          type: $('#tipo',wrap).value, pv: $('#pv',wrap).value||'0001', number: autogeneratedNumber,
          date: $('#fecha',wrap).value||today(),
          customer: $('#cli',wrap).value||'CF', cuit: $('#cuit',wrap).value||'CF',
          items: items.slice(),
          descuentoPct: Number($('#desc',wrap).value||0),
          totals: calcTotals(items, Number($('#desc',wrap).value||0), Number($('#perIva',wrap).value||0), Number($('#perIibb',wrap).value||0)),
          cae: String(Math.floor(1e12 + Math.random()*9e12)), caeVto: today()
        };
        const invs = await Simular.store.ensure('invoices', []); invs.push(invoice); await Simular.store.set('invoices', invs);
        // CxC
        const ar = await Simular.store.ensure('ar:docs', []);
        ar.push({ id: invoice.id, date: invoice.date, customer: invoice.customer, total: invoice.totals.total, balance: invoice.totals.total });
        await Simular.store.set('ar:docs', ar);
        // Limpiar reservas de OV (si había)
        const ovId = await Simular.store.get('current:ovId');
        if(ovId){
          const res = await Simular.store.ensure('reservations', []);
          const left = res.filter(r=> r.ovId!==ovId);
          await Simular.store.set('reservations', left);
          await Simular.store.set('current:ovId', null);
        }
        Simular.bus.emit('invoice.created', invoice);
        alert('Factura emitida ✅  '+invoice.id);
        renderInvoicePreview($('#preview',wrap), { doc:'FACTURA', tipo: invoice.type, pv: invoice.pv, nro: invoice.number, fecha: invoice.date, cliente: invoice.customer, cuit: invoice.cuit, items: invoice.items, descuentoPct: invoice.descuentoPct, totals: invoice.totals, cae: invoice.cae, caeVto: invoice.caeVto });
      };

      $('#printDoc',wrap).onclick = ()=>{
        const w = window.open('','_blank'); const html = '<html><body>'+ $('#preview',wrap).outerHTML +'</body></html>';
        w.document.write(html); w.document.close(); w.print(); setTimeout(()=>w.close(), 400);
      };

      $('#recibo',wrap).onclick = async ()=>{
        const docs = await Simular.store.ensure('ar:docs', []); const last = docs[docs.length-1];
        if(!last){ alert('No hay documento'); return; }
        const monto = prompt('Monto cobrado', String(last.balance||last.total||0));
        const m = Number(monto||0); if(!(m>0)) return;
        last.balance = Math.max(0, (last.balance||last.total||0) - m); await Simular.store.set('ar:docs', docs);
        const pays = await Simular.store.ensure('ar:pays', []);
        pays.push({ id:'RC-'+Date.now(), invoiceId:last.id, amount:m, date: new Date().toISOString() }); await Simular.store.set('ar:pays', pays);
        Simular.bus.emit('invoice.paid', {amount:m});
        alert('Recibo registrado ✅');
        render();
      };

      ['desc','perIva','perIibb','tipo','pv','nro','fecha','cli','cuit'].forEach(id => { const n=$('#'+id,wrap); if(n) n.oninput = render; });

      loadFromOV().then(render);
      return wrap;
    }

    // Tabs
    function selectTab(which){
      content.innerHTML = '';
      $('#tabCot').classList.remove('btn-primary');
      $('#tabOV').classList.remove('btn-primary');
      $('#tabFC').classList.remove('btn-primary');
      const tRem = $('#tabREM'); if(tRem) tRem.classList.remove('btn-primary');

      if(which==='COT'){ $('#tabCot').classList.add('btn-primary'); content.appendChild(viewCotizacion()); }
      else if(which==='OV'){ $('#tabOV').classList.add('btn-primary'); content.appendChild(viewOrden()); }
      else if(which==='FC'){ $('#tabFC').classList.add('btn-primary'); content.appendChild(viewFactura()); }
      else if(which==='REM'){ if(tRem){ tRem.classList.add('btn-primary'); } content.appendChild(viewRemito()); }
      else if(which==='NC'){ const tNC=$('#tabNC'); if(tNC) tNC.classList.add('btn-primary'); content.appendChild(viewNC()); }
      else { $('#tabCot').classList.add('btn-primary'); content.appendChild(viewCotizacion()); }
    }

    function bindTabs(){
      const bind = (id,tab)=>{
        const b = $('#'+id); if(!b) return;
        const h = (e)=>{ e.preventDefault(); selectTab(tab); };
        b.onclick = h; b.addEventListener('click', h);
      };
      bind('tabCot','COT'); bind('tabOV','OV'); bind('tabFC','FC'); if($('#tabREM')) bind('tabREM','REM'); if($('#tabNC')) bind('tabNC','NC');
      const bNew = $('#resetForm'); if(bNew){ bNew.onclick = async (e)=>{ e.preventDefault(); await Simular.store.set('current:toInvoice', null); await Simular.store.set('current:ovId', null); selectTab('COT'); }; }
      // Delegación local
      el.addEventListener('click', (ev)=>{
        const t = ev.target.closest('#tabCot,#tabOV,#tabFC,#tabREM,#resetForm'); if(!t) return;
        ev.preventDefault();
        if(t.id==='resetForm'){ selectTab('COT'); return; }
        const map = {tabCot:'COT', tabOV:'OV', tabFC:'FC', tabREM:'REM'}; if(map[t.id]) selectTab(map[t.id]);
      });
    }

    bindTabs();
    selectTab('COT');

    return { unmount(){} };
  }
});
