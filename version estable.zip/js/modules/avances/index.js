
Simular.registerModule({
  id:'avances', name:'Avances 15’', routes:[{ path:'#/avances', title:'Avances 15’' }],
  init(bus, store){ },
  async mount(el){
    el.innerHTML = `
      <div class="card">
        <h2>Avances ultra cortos (15’)</h2>
        <div class="toolbar" style="margin:10px 0">
          <div class="left">
            <button id="doNow" class="btn btn-primary">Registrar avance ahora</button>
          </div>
          <div class="right" style="display:flex;gap:10px;align-items:center">
            <label>Intervalo</label>
            <input id="interval" type="number" min="5" max="90" value="10" style="width:90px"/>
            <label>Recordatorio</label>
            <select id="enabled"><option value="true">Activado</option><option value="false">Desactivado</option></select>
            <button id="saveCfg" class="btn">Guardar</button>
            <button id="exportJson" class="btn">Exportar JSON</button>
            <button id="exportCsv" class="btn">Exportar CSV</button>
            <button id="testNotif" class="btn">Probar notificación</button>
          </div>
        </div>
        <div id="list" class="grid"></div>
      </div>
    `;
    Simular.help.inject(el, 'avances', `
<ul>
  <li>Capturá un avance ultra corto (15’): <em>Últimos</em>, <em>Próximos</em>, <em>Bloqueos</em> y <strong>Prioridad única</strong>.</li>
  <li>Atajo <strong>Ctrl/Cmd + J</strong> abre el modal al instante.</li>
  <li>Exportá JSON/CSV y ajustá el intervalo del recordatorio.</li>
</ul>
`);

    const $=s=>el.querySelector(s);

    const st = await Simular.store.ensure('settings:avances', { enabled:true, intervalMin:10, lastPromptAt:0 });
    $('#interval').value = st.intervalMin;
    $('#enabled').value = String(st.enabled);

    $('#doNow').onclick = ()=> (window.Simular.QuickCapture && window.Simular.QuickCapture.open && window.Simular.QuickCapture.open());
    $('#saveCfg').onclick = async ()=>{
      const v = { enabled: $('#enabled').value==='true', intervalMin: +$('#interval').value || 10, lastPromptAt: Date.now() };
      await Simular.store.set('settings:avances', v);
      alert('Configuración guardada ✅ (se aplica al próximo ciclo)');
    };
    $('#testNotif').onclick = ()=>{ try{ window.Simular.QuickCapture && window.Simular.QuickCapture.notify && window.Simular.QuickCapture.notify(); }catch(e){ console.error(e) } };

    async function render(){
      const cur = await Simular.store.ensure('logs:avances', []);
      const rows = cur.slice().reverse().map(r=>{
        const d = new Date(r.ts).toLocaleString();
        const esc = s => String(s||'').replace(/</g,'&lt;');
        return `<div class="card">
          <div class="row"><strong>${d}</strong><span>${r.windowMin||10}’</span></div>
          <div class="row"><span>Últimos 15:</span><span>${esc(r.past)}</span></div>
          <div class="row"><span>Próximos 15:</span><span>${esc(r.next)}</span></div>
          <div class="row"><span>Bloqueos:</span><span>${esc(r.blockers)}</span></div>
          <div class="row"><span>Prioridad:</span><span><strong>${esc(r.priority)}</strong></span></div>
        </div>`;
      }).join('') || '<p class="note">Sin registros todavía.</p>';
      $('#list').innerHTML = rows;
    }
    render();
    const off = Simular.bus.on('progress.logged', render);

    $('#exportJson').onclick = async ()=>{
      const cur = await Simular.store.ensure('logs:avances', []);
      const blob = new Blob([JSON.stringify(cur,null,2)], {type:'application/json'});
      const a = document.createElement('a'); a.href=URL.createObjectURL(blob); a.download='avances.json'; a.click(); URL.revokeObjectURL(a.href);
    };
    $('#exportCsv').onclick = async ()=>{
      const cur = await Simular.store.ensure('logs:avances', []);
      const header = ['ts','fecha','past','next','blockers','priority','windowMin'];
      const lines = [header.join(',')].concat(cur.map(r=>{
        const fecha = new Date(r.ts).toISOString();
        const esc = s => ('"'+String(s || '').replace(/"/g,'""')+'"');
        return [r.ts, fecha, esc(r.past), esc(r.next), esc(r.blockers), esc(r.priority), r.windowMin||10].join(',');
      }));
      const blob = new Blob([lines.join('\\n')], {type:'text/csv'});
      const a = document.createElement('a'); a.href=URL.createObjectURL(blob); a.download='avances.csv'; a.click(); URL.revokeObjectURL(a.href);
    };

    return { unmount(){ off && off(); } };
  }
});
