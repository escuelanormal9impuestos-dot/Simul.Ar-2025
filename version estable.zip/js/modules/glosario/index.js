
Simular.registerModule({ id:'glosario', name:'Glosario', routes:[{ path:'#/glosario', title:'Glosario' }],
  mount(el){
    el.innerHTML = `<div class="card"><h2>Glosario</h2><p class="note">Términos comunes del ERP educativo.</p>
      <ul><li><strong>OC:</strong> Orden de compra.</li><li><strong>CAE:</strong> Código de Autorización Electrónico.</li><li><strong>Kardex:</strong> Movimiento de stock.</li></ul></div>`;
    Simular.help.inject(el, 'glosario', `
<ul>
  <li>Definiciones rápidas de términos del ERP educativo.</li>
  <li>Se expande con ejemplos prácticos.</li>
</ul>
`);
 
    return {unmount(){}};
  }
});
