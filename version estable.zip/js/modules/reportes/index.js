
Simular.registerModule({ id:'reportes', name:'Reportes', routes:[{ path:'#/reportes', title:'Reportes' }],
  mount(el){
    el.innerHTML = `<div class="card"><h2>Reportes — KPIs simples</h2><pre id="data"></pre></div>`;
    Simular.help.inject(el, 'reportes', `
<ul>
  <li>Resumen técnico de datos de Ventas, Compras, IVA y Caja.</li>
  <li>Útil para depurar o validar escenarios del simulador.</li>
</ul>
`);

    const render=async()=>{ 
      const out={ ventas:await Simular.store.get('sales')||[], ivaVentas:await Simular.store.get('tax:ivaVentas')||[], ivaCompras:await Simular.store.get('tax:ivaCompras')||[], cash:await Simular.store.get('cash')||0 }; 
      el.querySelector('#data').textContent=JSON.stringify(out,null,2); 
    };
    const o1=Simular.bus.on('invoice.created',render), o2=Simular.bus.on('purchase.created',render), o3=Simular.bus.on('invoice.paid',render);
    render(); return {unmount(){ o1&&o1(); o2&&o2(); o3&&o3(); }};
  }
});
