
Simular.registerModule({ id:'rrhh', name:'RR.HH. Pro', routes:[{ path:'#/rrhh', title:'RR.HH. Pro' }],
  mount(el){
    el.innerHTML = `<div class="card"><h2>RR.HH. — liquidación</h2>
      <div style="display:flex;gap:10px;flex-wrap:wrap;margin:10px 0">
        <input id="periodo" placeholder="Periodo (YYYY-MM)" />
        <button id="cerrar" class="btn btn-primary">Cerrar nómina</button>
      </div><div id="out" class="note"></div></div>`;
    Simular.help.inject(el, 'rrhh', `
<ul>
  <li>Ingresá <strong>Periodo (YYYY-MM)</strong> y tocá <strong>Cerrar nómina</strong>.</li>
  <li>Impacta un evento en el Dashboard.</li>
</ul>
`);

    const $=s=>el.querySelector(s);
    $('#cerrar').onclick=()=>{ const per=$('#periodo').value||'2025-08'; Simular.bus.emit('payroll.closed',{period:per,totals:{rem:100}}); $('#out').textContent='Nómina cerrada para '+per; };
    return {unmount(){}};
  }
});
