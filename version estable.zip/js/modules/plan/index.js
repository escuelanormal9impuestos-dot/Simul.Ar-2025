
Simular.registerModule({ id:'plan', name:'Plan de Negocios', routes:[{ path:'#/plan', title:'Plan de Negocios' }],
  mount(el){
    el.innerHTML = `<div class="card"><h2>Plan de Negocios — estructura</h2>
      <ol><li>Inversión inicial</li><li>Fuentes de financiamiento</li><li>Presupuesto económico</li><li>Presupuesto financiero</li><li>Escenarios</li></ol>
    </div>`;
    Simular.help.inject(el, 'plan', `
<ul>
  <li>Guía de estructura base: inversión, financiamiento y presupuestos.</li>
  <li>Usalo como marco de un plan educativo simple.</li>
</ul>
`);
 return {unmount(){}};
  }
});
