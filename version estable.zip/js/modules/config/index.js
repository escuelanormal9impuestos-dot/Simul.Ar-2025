
Simular.registerModule({ id:'config', name:'Configuración', routes:[{ path:'#/config', title:'Configuración' }],
  mount(el){
    el.innerHTML = `<div class="card"><h2>Configuración</h2>
      <div style="display:flex;gap:10px;flex-wrap:wrap;margin:10px 0">
        <button id="reset" class="btn">Borrar datos demo</button>
      </div></div>`;
    Simular.help.inject(el, 'config', `
<ul>
  <li><strong>Borrar datos demo</strong> resetea el entorno de simulación.</li>
  <li>Útil antes de una clase o una nueva práctica.</li>
</ul>
`);

    document.getElementById('reset').onclick = async ()=>{
      await Simular.store.set('sales', []); await Simular.store.set('purchases', []); await Simular.store.set('inventory', {});
      await Simular.store.set('tax:ivaVentas', []); await Simular.store.set('tax:ivaCompras', []); await Simular.store.set('cash', 0);
      await Simular.store.set('logs:avances', []);
      alert('Datos demo borrados.');
    };
    return {unmount(){}};
  }
});
