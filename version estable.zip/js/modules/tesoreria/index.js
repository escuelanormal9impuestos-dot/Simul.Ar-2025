
Simular.registerModule({ id:'tesoreria', name:'Tesorería', routes:[{ path:'#/tesoreria', title:'Tesorería' }],
  init(bus, store){
    bus.on('invoice.paid', async (p)=>{ const cash=await store.ensure('cash',0); await store.set('cash', cash+(p.amount||0)); });
    bus.on('tax.payment.created', async (p)=>{ const cash=await store.ensure('cash',0); await store.set('cash', cash-(p.amount||0)); });
  },
  mount(el){
    el.innerHTML = `<div class="card"><h2>Tesorería</h2><p>Cobrar factura o pagar impuesto para ver movimiento.</p>
    <div style="display:flex;gap:10px;flex-wrap:wrap;margin:10px 0">
      <input id="monto" type="number" placeholder="Monto" />
      <button id="cobrar" class="btn btn-primary">Cobrar factura</button>
      <button id="pagar" class="btn">Pagar impuesto</button>
    </div>
    <div class="kpi"><div>Caja neta</div><div class="value" id="cash">$ 0</div></div></div>`;
    Simular.help.inject(el, 'tesoreria', `
<ul>
  <li>Ingresá un monto y elegí <strong>Cobrar factura</strong> o <strong>Pagar impuesto</strong>.</li>
  <li>Verás la variación en <strong>Caja neta</strong>.</li>
  <li>Al registrar <em>Recibo</em> desde Ventas, el saldo de CxC disminuye.</li>
</ul>
`);

    const $=s=>el.querySelector(s);
    const render=async()=>{ const cash=await Simular.store.ensure('cash',0); $('#cash').textContent='$ '+cash; };
    $('#cobrar').onclick=()=>{ const amt=parseFloat($('#monto').value||'0'); Simular.bus.emit('invoice.paid',{amount:amt}); render(); };
    $('#pagar').onclick=()=>{ const amt=parseFloat($('#monto').value||'0'); Simular.bus.emit('tax.payment.created',{taxType:'IVA',amount:amt}); render(); };
    render(); return {unmount(){}};
  }
});
