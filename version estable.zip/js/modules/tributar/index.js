
Simular.registerModule({ id:'tributar', name:'Tribut.Ar (sim)', routes:[{ path:'#/tributar', title:'Tribut.Ar' }],
  init(bus, store){
    function periodOf(dateStr){
      const d = dateStr ? new Date(dateStr) : new Date();
      const y = d.getFullYear(); const m = String(d.getMonth()+1).padStart(2,'0');
      return `${y}-${m}`;
    }
    bus.on('invoice.created', async (p)=>{ 
      const per = periodOf(p.date);
      const key = `tax:ivaVentas:${per}`;
      const cur=await store.ensure(key,[]);
      cur.push({id:p.id,date:p.date,vatBreakdown:p.vatBreakdown,neto:p.totals?.neto||0,iva:p.totals?.iva||0,total:p.totals?.gross||0, cae:p.cae, caeVto:p.caeVto});
      await store.set(key,cur); 
    });
    bus.on('purchase.created', async (p)=>{ 
      const per = periodOf(p.date);
      const key = `tax:ivaCompras:${per}`;
      const cur=await store.ensure(key,[]);
      cur.push({id:p.id,date:p.date,vatBreakdown:p.vatBreakdown,neto:p.totals?.bruto||0,iva:p.totals?.iva||0,total:p.totals?.gross||0});
      await store.set(key,cur); 
    });
  },
  async mount(el){
    el.innerHTML = `<div class="card"><h2>Tribut.Ar — Libros & DJ IVA (simulación)</h2>
      <div class="toolbar" style="margin:8px 0">
        <div class="left">
          <label>Período</label>
          <input id="per" placeholder="YYYY-MM" style="width:120px"/>
          <button id="ver" class="btn">Ver</button>
        </div>
        <div class="right">
          <button id="gen" class="btn btn-primary">Generar DJ IVA</button>
        </div>
      </div>
      <div class="grid cols-2">
        <div class="card"><strong>IVA Ventas</strong><pre id="ventas"></pre></div>
        <div class="card"><strong>IVA Compras</strong><pre id="compras"></pre></div>
      </div>
      <div class="card" style="margin-top:12px">
        <strong>DJ IVA del período</strong>
        <pre id="dj"></pre>
        <div style="display:flex;gap:8px">
          <button id="presentar" class="btn">Marcar presentada</button>
        </div>
      </div>
    </div>`;
    Simular.help.inject(el, 'tributar', `
<ul>
  <li>Elegí <strong>Período</strong> y consultá <strong>IVA Ventas</strong> / <strong>IVA Compras</strong>.</li>
  <li>Generá la <strong>DJ IVA</strong> y luego <em>Marcar presentada</em>.</li>
  <li>Los datos provienen de las facturas y compras simuladas.</li>
</ul>
`);

    const $=s=>el.querySelector(s);
    const now = new Date(); const perDefault = `${now.getFullYear()}-${String(now.getMonth()+1).padStart(2,'0')}`;
    $('#per').value = perDefault;

    async function loadPer(per){
      const v = await Simular.store.ensure(`tax:ivaVentas:${per}`, []);
      const c = await Simular.store.ensure(`tax:ivaCompras:${per}`, []);
      $('#ventas').textContent = JSON.stringify(v, null, 2);
      $('#compras').textContent = JSON.stringify(c, null, 2);
      const dj = await Simular.store.ensure(`tax:dj:${per}`, null);
      $('#dj').textContent = dj ? JSON.stringify(dj,null,2) : '(Sin generar)';
    }
    $('#ver').onclick = ()=> loadPer($('#per').value);

    $('#gen').onclick = async ()=>{
      const per = $('#per').value;
      const v = await Simular.store.ensure(`tax:ivaVentas:${per}`, []);
      const c = await Simular.store.ensure(`tax:ivaCompras:${per}`, []);
      const ivaV = v.reduce((a,r)=>a+(r.iva||0),0);
      const ivaC = c.reduce((a,r)=>a+(r.iva||0),0);
      const saldo = ivaV - ivaC;
      const dj = { per, ivaVentas:ivaV, ivaCompras:ivaC, saldo, fecha:new Date().toISOString(), estado:'GENERADA' };
      await Simular.store.set(`tax:dj:${per}`, dj);
      $('#dj').textContent = JSON.stringify(dj,null,2);
      alert('DJ generada ✅');
    };

    $('#presentar').onclick = async ()=>{
      const per = $('#per').value;
      const dj = await Simular.store.ensure(`tax:dj:${per}`, null);
      if(!dj){ alert('Primero generá la DJ'); return; }
      dj.estado='PRESENTADA'; dj.presentadaEn = new Date().toISOString();
      await Simular.store.set(`tax:dj:${per}`, dj);
      $('#dj').textContent = JSON.stringify(dj,null,2);
      alert('Marcada como PRESENTADA ✅');
    };

    await loadPer(perDefault);
    return {unmount(){}};
  }
});
