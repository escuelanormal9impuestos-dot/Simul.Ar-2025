
Simular.registerModule({ id:'contratos', name:'Sociedades / Contratos', routes:[{ path:'#/contratos', title:'Sociedades' }],
  mount(el){ el.innerHTML = `<div class="card"><h2>Sociedades & Contratos</h2><p class="note">Plantillas: SH, SRL, SA, SAS; NDAs; locación de servicios.</p></div>`;
    Simular.help.inject(el, 'contratos', `
<ul>
  <li>Plantillas demo: SH, SRL, SA, SAS, NDA, locación de servicios.</li>
  <li>Objetivo pedagógico: reconocer cláusulas comunes.</li>
</ul>
`);
 return {unmount(){}}; }
});
