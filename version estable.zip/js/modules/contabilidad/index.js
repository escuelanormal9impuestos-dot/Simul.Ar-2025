
Simular.registerModule({ id:'contabilidad', name:'Contabilidad', routes:[{ path:'#/contabilidad', title:'Contabilidad' }],
  mount(el){
    el.innerHTML = `<div class="card"><h2>Contabilidad — eventos oídos</h2><div id="log"></div></div>`;
    Simular.help.inject(el, 'contabilidad', `
<ul>
  <li>Se registran eventos automáticos por ventas, compras, cobros y pagos.</li>
  <li>Próximamente: plan de cuentas y asientos visibles.</li>
</ul>
`);

    const log=el.querySelector('#log'); const add=t=>{const p=document.createElement('div'); p.textContent=t; log.prepend(p);};
    const o1=Simular.bus.on('invoice.created',p=>add('Asiento venta auto')); const o2=Simular.bus.on('purchase.created',p=>add('Asiento compra auto'));
    const o3=Simular.bus.on('invoice.paid',p=>add('Asiento cobro')); const o4=Simular.bus.on('tax.payment.created',p=>add('Asiento pago impuesto'));
    return {unmount(){ o1&&o1(); o2&&o2(); o3&&o3(); o4&&o4(); }};
  }
});
