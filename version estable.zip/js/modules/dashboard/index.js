
Simular.registerModule({
  id:'dashboard',
  name:'Dashboard',
  routes:[{ path:'#/home', title:'Dashboard' }],
  init(bus, store){
    bus.on('invoice.created', async (p)=>{
      const cur = await store.ensure('sales', []);
      cur.push({id:p.id, total:p.totals?.gross||0, date:new Date().toISOString()});
      await store.set('sales', cur);
    });
    bus.on('purchase.created', async (p)=>{
      const cur = await store.ensure('purchases', []);
      cur.push({id:p.id, total:p.totals?.gross||0, date:new Date().toISOString()});
      await store.set('purchases', cur);
    });
  },
  async mount(el){
    el.innerHTML = `
      <div class="grid cols-3">
        <div class="card section">
          <h3>📈 Ventas</h3>
          <div class="kpi-big" id="ventasTotal">$ 0</div>
          <div class="row"><span>#000123 - Alimentos SRL</span><span>$ 82.100</span></div>
          <div class="row"><span>#000124 - Pérez Hnos</span><span>$ 18.500</span></div>
          <div class="row"><span>#000125 - Lara S.A.</span><span>$ 41.300</span></div>
          <div class="row"><span>#000126 - Vidal</span><span>$ 15.900</span></div>
          <div class="row"><span>#000127 - Techno</span><span>$ 52.000</span></div>
          <div class="spark" style="margin-top:10px"></div>
          <div style="display:flex;justify-content:flex-end;margin-top:8px">
            <button id="goVentas" class="btn">Ver todo</button>
          </div>
        </div>

        <div class="card section">
          <h3>🧾 Compras</h3>
          <div class="kpi-big" id="comprasOC">4 OC</div>
          <div class="row"><span>OC #4501 - Prov SA</span><span>$ 110.000</span></div>
          <div class="row"><span>OC #4502 - Prov Norte</span><span>$ 220.000</span></div>
          <div class="row"><span>FC #7812 - PapelSur</span><span>$ 90.000</span></div>
          <div class="row"><span>FC #7813 - Tintas</span><span>$ 70.000</span></div>
          <div class="spark" style="margin-top:10px"></div>
          <div style="display:flex;justify-content:flex-end;margin-top:8px">
            <button id="goCompras" class="btn btn-primary">Cargar OC</button>
          </div>
        </div>

        <div class="card section">
          <h3>📦 Stock</h3>
          <div class="kpi-big">12 SKU bajo mínimo</div>
          <div class="row"><span>A4 75gr</span><span class="badge" style="background:rgba(239,122,122,.12);border-color:rgba(239,122,122,.35)">Bajo</span></div>
          <div class="row"><span>Tóner 12A</span><span class="badge" style="background:rgba(239,122,122,.12);border-color:rgba(239,122,122,.35)">Bajo</span></div>
          <div class="row"><span>Caja chica</span><span class="badge" style="background:rgba(136,212,152,.15);border-color:rgba(136,212,152,.35)">Ok</span></div>
          <div class="row"><span>Pendrive 32GB</span><span class="badge" style="background:rgba(239,122,122,.12);border-color:rgba(239,122,122,.35)">Bajo</span></div>
          <div class="row"><span>Monitor 24"</span><span class="badge" style="background:rgba(136,212,152,.15);border-color:rgba(136,212,152,.35)">Ok</span></div>
          <div class="spark" style="margin-top:10px"></div>
          <div style="display:flex;justify-content:flex-end;margin-top:8px">
            <button id="goStock" class="btn btn-primary">Nuevo producto</button>
          </div>
        </div>
      </div>

      <div class="grid cols-2" style="margin-top:16px">
        <div class="card section">
          <h3>💰 Contabilidad</h3>
          <div class="kpi-big">Caja $ 180.000</div>
          <div class="row"><span>Bancos $ 2.100.000 · Asientos por revisar: 3 · IVA neto: $ -140.000</span><span></span></div>
          <div style="display:flex;gap:8px;margin-top:8px">
            <button id="goConta" class="btn">Plan de cuentas</button>
            <button class="btn">Libros IVA</button>
          </div>
        </div>

        <div class="card section">
          <h3>🧮 Tribut.Ar (sim)</h3>
          <div class="row"><span>Último CAE</span><span class="badge">D-001-0000127 · 2025-08-27</span></div>
          <div class="row"><span>Vence IVA</span><span class="badge">IVA · 5d</span></div>
          <div class="row"><span>Vence IIBB</span><span class="badge">IIBB · 7d</span></div>
        </div>
      </div>

      <div class="card section">
        <h3>💳 Cuentas por cobrar</h3>
        <div class="kpi-big" id="arSaldo">$ 0</div>
        <div id="arList" class="row"></div>
      </div>

      <div class="card section" style="margin-top:16px">
        <h3>👥 RR.HH. Pro</h3>
        <div class="kpi-big">9 días</div>
        <div class="row"><span>Nómina: 18 · Presentismo: 94% · Ausentismo: 6%</span><span></span></div>
        <div style="display:flex;gap:8px;margin-top:8px">
          <button id="emitPayroll" class="btn btn-primary">Cerrar nómina</button>
          <button id="goRRHH" class="btn">Abrir RR.HH.</button>
        </div>
      </div>
    `;
    Simular.help.inject(el, 'dashboard', `
<ul>
  <li>Revisá KPIs de Ventas, Compras, Stock, RR.HH. y <strong>Cuentas por Cobrar</strong>.</li>
  <li>Usá los botones para abrir cada módulo y profundizar.</li>
  <li>Los widgets reaccionan a facturas, compras y nóminas.</li>
</ul>
`);


    const $=s=>el.querySelector(s);
    $('#goVentas').onclick = ()=>location.hash='#/ventas';
    $('#goCompras').onclick = ()=>location.hash='#/compras';
    $('#goStock').onclick = ()=>location.hash='#/stock';
    $('#goConta').onclick = ()=>location.hash='#/contabilidad';
    $('#goRRHH').onclick = ()=>location.hash='#/rrhh';
    $('#emitPayroll').onclick = ()=>Simular.bus.emit('payroll.closed', {period:'2025-08'});

    async function refreshVentas(){
      const data = await Simular.store.ensure('sales',[]);
      const total = data.reduce((acc, r)=> acc + (r.total||0), 0);
      const kpi = el.querySelector('#ventasTotal');
      if (kpi) kpi.textContent = '$ ' + total.toFixed(2);
    }
    await refreshVentas();
    async function refreshAR(){
      const docs = await Simular.store.ensure('ar:docs', []);
      const saldo = docs.reduce((a,d)=> a + (d.balance||0), 0);
      const k = el.querySelector('#arSaldo'); if(k) k.textContent = '$ ' + saldo.toFixed(2);
      const lst = el.querySelector('#arList'); if(lst) lst.innerHTML = docs.slice(-5).reverse().map(d=>`<div class='row'><span>${d.id}</span><span>$ ${(d.balance||0).toFixed(2)}</span></div>`).join('') || '<div class="row">Sin documentos</div>';
    }
    await refreshAR();
    const offAR1 = Simular.bus.on('invoice.created', refreshAR), offAR2 = Simular.bus.on('invoice.paid', refreshAR);
    const off = Simular.bus.on('invoice.created', refreshVentas);
    return {unmount(){ off && off(); offAR1&&offAR1(); offAR2&&offAR2(); }};
  }
});
