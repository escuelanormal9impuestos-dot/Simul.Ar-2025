
Simular.registerModule({
  id:'stock', name:'Stock', routes:[{ path:'#/stock', title:'Stock' }],
  init(bus, store){
    (async()=>{
      const s = await store.ensure('inventory', {'SKU-001':10,'SKU-002':5,'SKU-003':20});
      await store.set('inventory', s);
    })();
    bus.on('invoice.created', async (p)=>{
      const s = await store.ensure('inventory', {});
      (p.items||[]).forEach(it=>{ s[it.sku] = (s[it.sku]||0) - (it.q||1); });
      await store.set('inventory', s);
    });
    bus.on('purchase.created', async (p)=>{
      const s = await store.ensure('inventory', {});
      (p.items||[{sku:'SKU-001', q:1}]).forEach(it=>{ s[it.sku] = (s[it.sku]||0) + (it.q||1); });
      await store.set('inventory', s);
    });
  },
  mount(el){
    el.innerHTML = `<div class="card"><h2>Stock — kardex mínimo</h2><div id="inv"></div><div style="margin-top:12px"><strong>Reservas</strong><div id="res"></div></div></div>`;
    Simular.help.inject(el, 'stock', `
<ul>
  <li>El listado muestra cantidades actuales por SKU.</li>
  <li><strong>Reservas</strong> se crean al confirmar una OV y se liberan al facturar.</li>
  <li>Las compras suman stock; las ventas facturadas descuentan.</li>
</ul>
`);

    const render = async()=>{ 
      const s = await Simular.store.ensure('inventory', {'SKU-001':10,'SKU-002':5,'SKU-003':20});
      el.querySelector('#inv').innerHTML = Object.entries(s).map(([k,v])=>`<div>${k}: <strong>${v}</strong></div>`).join('');
      const res = await Simular.store.ensure('reservations', []);
      const agg = {};
      for(const r of res){ (r.items||[]).forEach(it=>{ agg[it.sku]=(agg[it.sku]||0)+ (it.q||0); });}
      el.querySelector('#res').innerHTML = Object.keys(agg).length? Object.entries(agg).map(([k,v])=>`<div>${k}: <strong>${v}</strong></div>`).join('') : '<div class="note">Sin reservas</div>';
    };
    const off1=Simular.bus.on('invoice.created',render), off2=Simular.bus.on('purchase.created',render);
    render(); 
    return {unmount(){ off1&&off1(); off2&&off2(); }};
  }
});
